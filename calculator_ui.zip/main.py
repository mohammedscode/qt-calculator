import sys
from PyQt5.QtWidgets import QApplication
from calculator import CalculatorWindow

app = QApplication(sys.argv) #Create an application  

calculator = CalculatorWindow() #Create an object of type CalculatorWindow

sys.exit(app.exec_())

