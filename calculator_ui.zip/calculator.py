from PyQt5 import QtWidgets
from windows2 import Ui_MainWindow

class CalculatorWindow(QtWidgets.QMainWindow,Ui_MainWindow):
    def __init__(self):
        super().__init__() #Calls the init method of the base classes (QMainWindow and Ui_MainWindow)
        self.setupUi(self) #Part of the Ui-MainWindow. Calls the designed UI
        self.show #Shows the UI on screen


